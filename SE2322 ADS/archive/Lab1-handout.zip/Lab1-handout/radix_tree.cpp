#include "radix_tree.hpp"

RadixTree::RadixTree()
{
    // To Be Implemented
}

RadixTree::~RadixTree()
{
    // To Be Implemented
}

void RadixTree::insert(int32_t value)
{
    // To Be Implemented
}

void RadixTree::remove(int32_t value)
{
    // To Be Implemented
}

bool RadixTree::find(int32_t value)
{
    // To Be Implemented
    return true;
}

uint32_t RadixTree::size()
{
    // To Be Implemented
    return 0;
}

uint32_t RadixTree::height()
{
    // To Be Implemented
    return 0;
}
