#include "compressed_radix_tree.hpp"

CompressedRadixTree::CompressedRadixTree()
{
    // To Be Implemented
}

CompressedRadixTree::~CompressedRadixTree()
{
    // To Be Implemented
}

void CompressedRadixTree::insert(int32_t value)
{
    // To Be Implemented
}

void CompressedRadixTree::remove(int32_t value)
{
    // To Be Implemented
}

bool CompressedRadixTree::find(int32_t value)
{
    // To Be Implemented
    return true;
}

uint32_t CompressedRadixTree::size()
{
    // To Be Implemented
    return 0;
}

uint32_t CompressedRadixTree::height()
{
    // To Be Implemented
    return 0;
}
