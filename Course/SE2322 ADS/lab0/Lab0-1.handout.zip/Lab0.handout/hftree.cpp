#include "hftree.h"

hfTree::hfTree(const std::string &text, const Option op)
{
    // TODO: Your code here
}

std::map<std::string, std::string> hfTree::getCodingTable()
{
    // TODO: Your code here
    return std::map<std::string, std::string>();
}