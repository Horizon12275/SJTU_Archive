# 编译运行方法
g++ -std=c++11 -pthread parallel.cpp -o parallel

./parallel.exe

# 正确答案如下（供参考）
F39	63245986
F40	102334155
F41	165580141