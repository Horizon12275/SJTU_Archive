#include "cachelab.h"
#include <stdlib.h>
#include <getopt.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <limits.h>

int h = 0, v = 0, s = 0, E = 0, b = 0, S = 0; // 选项参数

int Hits = 0, Misses = 0, Evictions = 0; // 最终的三个参数

char input_string[1000]; // 输入行

typedef struct
{
    int valid_bit;
    int tag_bit;
    int time_stamp;
} cache_line, *cache_line_pointer, **cache; // cache_line是cache的元素

cache my_cache = NULL; // cache是一个二维数组

void init_cache() // 初始化cache
{
    my_cache = (cache)malloc(sizeof(cache_line_pointer) * S);
    for (int i = 0; i < S; i++)
    {
        my_cache[i] = (cache_line_pointer)malloc(sizeof(cache_line) * E);
        for (int j = 0; j < E; j++)
        {
            my_cache[i][j].valid_bit = 0;
            my_cache[i][j].tag_bit = -1;
            my_cache[i][j].time_stamp = -1;
        }
    }
}

void update(unsigned int address) // 更新cache
{
    int setindex_address = (address >> b) & ((-1U) >> (64 - s));
    int tag_address = address >> (b + s);

    int max_time_stamp = INT_MIN;
    int max_time_stamp_index = -1;

    // 查找是否命中
    for (int i = 0; i < E; i++)
    {
        if (my_cache[setindex_address][i].tag_bit == tag_address)
        {
            my_cache[setindex_address][i].time_stamp = 0;
            Hits++;
            return;
        }
    }

    // 没有命中，查找是否有空位
    for (int i = 0; i < E; ++i)
    {
        if (my_cache[setindex_address][i].valid_bit == 0)
        {
            my_cache[setindex_address][i].valid_bit = 1;
            my_cache[setindex_address][i].tag_bit = tag_address;
            my_cache[setindex_address][i].time_stamp = 0;
            Misses++;
            return;
        }
    }

    // 没有空位，需要替换
    Evictions++;
    Misses++;

    for (int i = 0; i < E; i++)
    {
        if (my_cache[setindex_address][i].time_stamp > max_time_stamp)
        {
            max_time_stamp = my_cache[setindex_address][i].time_stamp;
            max_time_stamp_index = i;
        }
    }
    my_cache[setindex_address][max_time_stamp_index].tag_bit = tag_address;
    my_cache[setindex_address][max_time_stamp_index].time_stamp = 0;
}

void update_time_stamp() // 更新时间戳
{
    for (int i = 0; i < S; i++)
        for (int j = 0; j < E; j++)
            if (my_cache[i][j].valid_bit == 1)
                my_cache[i][j].time_stamp++;
}

void parse_trace() // 解析trace文件
{
    FILE *trace_file = fopen(input_string, "r"); // 读取文件名
    if (trace_file == NULL)
    {
        printf("file open error");
        exit(-1);
    }
    char operation;       // 操作参数
    unsigned int address; // 地址
    int size;             // 大小
    while (fscanf(trace_file, " %c %xu,%d\n", &operation, &address, &size) > 0)
    {
        switch (operation)
        {
        case 'M':
            update(address);
            update(address);
            break;
        case 'L':
            update(address);
            break;
        case 'S':
            update(address);
            break;
        default:
            break;
        }
        update_time_stamp(); // 更新时间戳
    }
    fclose(trace_file);
}

void free_cache()
{
    for (int i = 0; i < S; i++)
        free(my_cache[i]);
    free(my_cache);
}

int main(int argc, char *argv[])
{
    int opt = -1; // 选项参数

    while ((opt = (getopt(argc, argv, "hvs:E:b:t:"))) != -1)
    {
        switch (opt)
        {
        case 'h':
            break;
        case 'v':
            break;
        case 's':
            s = atoi(optarg);
            break;
        case 'E':
            E = atoi(optarg);
            break;
        case 'b':
            b = atoi(optarg);
            break;
        case 't':
            strcpy(input_string, optarg);
            break;
        default:
            break;
        }
    }

    if (s <= 0 || E <= 0 || b <= 0 || input_string == NULL) // 选项参数不合法
        return -1;

    S = pow(2, s);

    FILE *trace_file = fopen(input_string, "r");
    if (trace_file == NULL)
    {
        printf("file open error");
        exit(-1);
    }

    init_cache();  // 初始化cache
    parse_trace(); // 解析trace文件
    free_cache();  // 释放cache

    printSummary(Hits, Misses, Evictions);

    return 0;
}